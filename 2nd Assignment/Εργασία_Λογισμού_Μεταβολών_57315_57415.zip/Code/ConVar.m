function [ c,ceq ] = ConVar(x)
c=[];
ceq=x(1)*x(2)+1-x(3);

end

